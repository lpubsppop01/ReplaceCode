﻿using System;

namespace Lpubsppop01.HogeLib
{
    public enum CommandKind
    {
        A,
        B
    }

    public class Command
    {
        public CommandKind Kind { get; set; }

        public static bool TryParse(string text, out Command command)
        {
            command = null;
            if (!Enum.TryParse<CommandKind>(text, out var kind)) return false;
            command = new Command { Kind = kind };
            return true;
        }
    }
}
