﻿using System.IO;

namespace Lpubsppop01.HogeLib
{
    class TextFileInfo
    {
        public TextFileInfo(string path)
        {
            Path = path;
            NewLineKind = File.ReadAllText(path).DetectNewLineKind() ?? NewLineKind.CRLF;
        }

        public string Path { get; private set; }
        public NewLineKind NewLineKind { get; private set; }
    }

    enum NewLineKind
    {
        CRLF, LF
    }

    static class NewLineUtility
    {
        public static NewLineKind? DetectNewLineKind(this string str)
        {
            int iLF = str.IndexOf('\n');
            if (iLF == -1) return null;
            if (iLF == 0) return NewLineKind.LF;
            return (str[iLF - 1] == '\r') ? NewLineKind.CRLF : NewLineKind.LF;
        }
    }
}
