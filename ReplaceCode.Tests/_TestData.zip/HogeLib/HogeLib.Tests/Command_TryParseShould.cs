using Xunit;

namespace Lpubsppop01.HogeLib.Tests
{
    public class Command_TryParseShould
    {
        [Fact]
        public void ReturnTrueGivenCommandKindString()
        {
            Assert.True(Command.TryParse("A", out Command c1) && c1.Kind == CommandKind.A);
            Assert.True(Command.TryParse("B", out Command c2) && c2.Kind == CommandKind.B);
            Assert.False(Command.TryParse("C", out c2));
        }
    }
}
